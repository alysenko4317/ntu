package com.khpi.lections.springbootmin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMinApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMinApplication.class, args);
	}

}

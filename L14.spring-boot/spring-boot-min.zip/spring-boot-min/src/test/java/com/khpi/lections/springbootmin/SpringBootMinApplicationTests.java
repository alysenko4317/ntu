package com.khpi.lections.springbootmin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMinApplicationTests {

	@Test
	void contextLoads() {
	}

}
